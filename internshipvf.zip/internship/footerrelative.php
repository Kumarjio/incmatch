<style>
.footer{
		text-align: center;
		background-color: #192535;
		color: #a3a5a8;
		
	}
	footer{
		margin: 0;
	}
	p{
		display: inline-block;
		color: #a3a5a8;
	}
	h2{
		color: #ffffff;
	}

@media screen and (min-width: 1000px){
	.footer{
		width: 100%;
	}
}
</style>


<div style="clear: both"></div>
<div class="footer">
<footer>

	
	
	&copy; 2017 <p>Whatcom Community College</p>
	<h2>The I.N.C(IT, Networking, Cybersecurity) Job/Internship Matching Program is a project sponsored by CyberWatch West</h2>
	<h2 style="color: #ffffff; font-size: 24px">This publication was created with funds from a National Science Foundation grant, DUE-1500375. </h2>
	
	
	
</footer>
</div>
</body>
</html>

