<?php require("siteheader.php"); ?>

<?php

 $schools[0] = "Bates Technical College";
 $schools[2] = " Burlington-Edison High School";
 $schools[3] = " Central Washington University";
 $schools[4] = " Clark College";
 $schools[5] = "Clover Park Technical College";
 $schools[6]  = "Columbia Basin College";
 $schools[7]  = "Eastern Washington University";
 $schools[8]  = "Edmonds Community College";
 $schools[9]  = "Everett Community College";
 $schools[10]  = "Green River College";
 $schools[11]  = "Highline College";
 $schools[12]  = "Lynden High School";
 $schools[13]  = "Marysville-Pilchuck High School";
 $schools[14]  = "North Seattle College";
 $schools[15]  = "Olympic College";
 $schools[16]  = "Peninsula College";
 $schools[17]  = "Sedro Woolley High School";
 $schools[18]  = "South Seattle College";
 $schools[19]  = "Spokane Falls Community College";
 $schools[20]  = "Tacoma Community College";
 $schools[21]  = "The Evergreen State College";
 $schools[22]  = "University of Washington";
 $schools[23]  = "Western Washington University";
 $schools[24]  = "Whatcom Community College";
$schools[25]  = "Central Oregon Community College";
 $schools[26]  = "Chemeketa Community College";
 $schools[27]  = "Lewis and Clark College";
 $schools[28]  = "Linn-Benton Community College";
 $schools[29]  = "Mt. Hood Community College";
 $schools[30]  = "Oregon Institute of Technology";
 $schools[31]  = "Portland Community Colleg";
 $schools[32] = "American River College";
 $schools[33]  = "Antelope Valley College";
 $schools[34]  = "Barstow Community College";
 $schools[35]  = "Bullard High School";
 $schools[36]  = "California State Polytechnic University—Pomona";
 $schools[37]  = "California State Polytechnic University—San Luis Obispo";
 $schools[38]  = "California State University Channel Islands";
 $schools[39]  = "California State University—Chico";
 $schools[40]  = "California State University—San Bernardino";
 $schools[41]  = "Career Education Center";
 $schools[42]  = "Cerritos College";
 $schools[43]  = "Cerro Coso Community College";
$schools[44]  = "Chaffey College";
 $schools[45]  = "Citrus College";
 $schools[46]  = "City College of San Francisco";
 $schools[47]  = "Clovis Community College";
 $schools[48]  = "Coast Union High School";
 $schools[49]  = "Coastline Community College";
 $schools[50]  = "College of Marin";
 $schools[51]  = "College of San Mateo";
 $schools[52]  = "College of the Canyons";
 $schools[53]  = "College of the Redwoods";
 $schools[54]  = "Coltan-Redlands-Yucaipa Regional Occupational Program";
 $schools[55]  = "Communications and Technology School";
 $schools[56]  = "Consumnes Community College";
 $schools[57]  = "Cuyamaca College";
 $schools[58]  = "Cypress College";
 $schools[59]  = "De Anza College";
 $schools[60]  = "Diablo Valley College";
 $schools[61]  = "Edward Roybal Learning Center";
 $schools[62]  = "Evergreen Valley College";
 $schools[63]  = "Folsom Lake College";
 $schools[64]  = "Fullerton College";
 $schools[65]  = "Glendale Community College";
 $schools[66]  = "Hartnell College";
 $schools[67]  = "Irvington High School";
 $schools[68]  = "John F. Kennedy High School";
 $schools[69]  = "Las Positas College";
 $schools[70]  = "Long Beach City College";
 $schools[71]  = "Los Angeles Mission College";
 $schools[72]  = "Los Angeles Southwest College";
 $schools[73]  = "Los Medanos College";
 $schools[74]  = "Luther Burbank High School";
 $schools[75]  = "Merced College";
 $schools[76]  = "Monterey Peninsula College";
 $schools[77] = " National City Adult School";
 $schools[78] = " National University";
 $schools[79] = " Oak Park High School";
 $schools[80]  = "Olympian High School";
 $schools[81]  = "Pasadena City College";
 $schools[82]  = "Ramona High School";
 $schools[83]  = "Rancho Santiago Community College District";
 $schools[84] = " Rio Hondo College";
 $schools[85] = " Riverside City College";
 $schools[86]  = "Rocklin High School";
 $schools[87]  = "Sacramento City College";
 $schools[88]  = "Saddleback College";
 $schools[89]  = "San Bernardino County Regional Occupational Program";
 $schools[90]  = "San Bernardino Valley College";
 $schools[91]  = "San Diego City College";
 $schools[92]  = "San Jose State University";
 $schools[93]  = "Santa Monica Collegev";
 $schools[94]  = "Santa Rosa Junior College - Petaluma";
 $schools[95]  = "Santa Ynez Valley Union High School";
 $schools[96]  = "Sierra College";
 $schools[97]  = "Trident University International";
 $schools[98]  = "Troy High School";
 $schools[99]  = "Valencia High School";
 $schools[100]  = "Venice Skills Center";
 $schools[101]  = "West Los Angeles College";
 $schools[102]  = "Westchester Enriched Sciences Magnets High School";
 $schools[103]  = "Yuba College";
 $schools[104]  = "Aaniiih Nakoda College";
 $schools[105]  = "Missoula College - University of Montana";
 $schools[106]  = "Sentinal High School";
 $schools[107]  = "North Idaho College";
 $schools[108]  = "University of Idaho";
 $schools[109]  = "Cheyenne High School";
 $schools[110]  = "College of Southern Nevada";
 $schools[111]  = "Eldorado High School";
 $schools[112]  = "Shadow Ridge High School";
 $schools[113]  = "Truckee Meadows Community College";
 $schools[114]  = "Valley High School";
 $schools[115]  = "Embry-Riddle Aeronautical University, Prescott";
 $schools[116]  = "Estrella Mountain Community College";
 $schools[117] = " Glendale Community College";
 $schools[118] = " Grand Canyon University";
 $schools[119] = " University of Arizona";
 $schools[120] = " Pleasant Grove High School";
 $schools[121] = " Utah Valley University";
 $schools[122] = " Laramie County Community College";
 $schools[123] = " Arapahoe Community College";
 $schools[124] = " Chaparral High School";
 $schools[125] = " Metropolitan State University of Denver";
 $schools[126] = " Pikes Peak Community College";
 $schools[127] = " Red Rocks Community College";
 $schools[128] = " Regis University";
 $schools[129] = " Central New Mexico Community College";
 $schools[130] = " Eastern New Mexico University—Ruidoso";
 $schools[131] = " Mescalero Apache School";
 $schools[132] = " New Mexico Institute of Mining and Technology";
 $schools[133] = " San Juan College";
 $schools[134] = " Santa Fe Community College";
 $schools[135] = " University of New Mexico-Valencia";
 $schools[136] = " University of North Dakota";
 $schools[137] = " Metropolitan Community College";
 $schools[138] = " Northeast Community College";
 $schools[139] = " Central Texas College";
 $schools[140] = " Houston Community College";
 $schools[141] = " Laredo Community College";
 $schools[142] = " Lone Star College-Montgomery";
 $schools[143] = " Northeast Texas Community College";
 $schools[144] = " Parker University";
 $schools[145] = " South Texas College";
 $schools[146] = " Texas A&M University-Corpus Christi";
 $schools[147] = " University of Texas at El Paso";
 $schools[148] = " St Louis Community College—Forest Park";
 $schools[149] = " Lake Superior College";
 $schools[150] = " Metropolitan State University";
 $schools[151] = " Miami Dade College";
 $schools[152] = " Roane State Community College";
 $schools[153] = " Cuyahoga Community College";
 $schools[154]  = "Terra State Community College";
 $schools[155]  = "American Public University";
 $schools[156]  = "Sacred Heart University";


?>
<div style="margin: 0 5% 0 5%">
<h1 style="margin: 0; left: 0">Enter the name of the school you are associated with, either as a current student or an alumni. The school must be a CyberWatch West member in order for you to participate in this matching program.</h1><br>
<h2>Please enter the full name of your school.  <br></h2><h3>Example: Texas A&M University-Kingsville</h3>
<form action="<?php htmlspecialchars($_SERVER['PHP_SELF']); ?>" method='post'>

<input type="text" name="school" /><br></br>
<input type="submit" name="submit" value="submit">
</form>
</div>
<?php
if(isset($_POST['submit'])){
	$school = $_POST['school'];
	$tr = "no";
	$count = 0;
	while($count < count($schools)){
		if(strToLower($school) == strToLower($schools[$count])){
			$tr = "yes";
			
			break;
		}
		else{
			$tr = "no";
			
		}
		$count++;
	}
	if(strcmp($tr, "yes") == 0){
		header('Refresh: 0; url=' . SKRSIGNUP);
			//echo "<div style='border: 2px solid #000000; width: 50%; margin: auto; border-radius: 15px; box-shadow: 4px 2px 4px grey'>You will be redirected to our seeker sign-up page shortly.</div>";
			//header("location: http://cwwinternship.cyberwatchwest.org/internship/seekersignup.php");
			echo "<script>alert('You will be redirected to our seeker sign-up page shortly.')</script>";
	}
	else{
		echo "<script>alert('Your school is not a member of the CyberWatch West Community. Please contact your school administrator and direct them to CyberWatchWest.org.')</script>";
		//echo strcmp($tr, "yes");
		//echo strcmp($tr, "no");
		
	}
	
}
?>



































