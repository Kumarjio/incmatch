<style>
.footer{
		position: relative;
		text-align: center;
		background-color: #febf00;
		color: #192535;
		
		
	}
	footer{
		
	}
	.footer-inside{
		color: #192535;
	}
	p{
		display: inline-block;
		color: #192535;
	}

</style>


<div style="clear: both"></div>
<div class="footer">
<footer>

	
	
	&copy; 2017 <p>Whatcom Community College</p>
	<h2 style="color: #192535; font-size: 24px">This publication was created with funds from a National Science Foundation grant, DUE-1500375. </h2>
	
</footer>
</div>
</body>
</html>