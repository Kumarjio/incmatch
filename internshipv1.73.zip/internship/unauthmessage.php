<?php  require("header.php"); ?>




<div class="jobBoard">
	<h2>We will email you once your Information has been verified</h2>
</div>






















<?php require("footer.php"); ?>