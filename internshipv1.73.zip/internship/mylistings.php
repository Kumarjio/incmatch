<?php  require("header.php"); 
 ?>

 <script type="text/javascript">
$(document).ready(function(){
	$("#pointer").css("cursor", "pointer");
    $("#pointer").click(function(){
       $("#blurb").hide();
        var button = $('<input type="submit" name="showH1" value="Press Me to see the introduction" />');
        button.css({"margin": "0 0 2em 5em", "cursor": "pointer"});
      	
        $("div").eq(1).append(button);
        button.click(function(){
        	$("#blurb").show();
        	button.hide();
        });
       
    });
    $("#blurb").dblclick(function(){
    
    	$(this).hide();
    });
     
});

</script>


<div style="padding: 0 2em 0 2em">
<h1 id="blurb" style="margin: 1em 0 1em 2em; background-color: #feb600; border-radius: 10px; padding: 2em">
Here are all the listings that you have posted! <br> </br> 
<span style="color: #300" id="pointer"> Click to remove introduction</span><br>
</h1> </div>
<div style="width: 90%; border: 2px solid #ffffff9; margin: auto; box-shadow: 4px 5px 5px grey; margin-bottom: .8em">
<?php 	
	 getJobBoardInfo();
	//echo $_SESSION['id'];
	sessionTimeOut();
	
?>
</div>








<?php require("footerrelative.php"); ?>