<style>
.footer{
		position: relative;
		text-align: center;
		background-color: #192535;
		color: #a3a5a8;
		width: 100%;
		margin: auto;
		bottom: 0;
		overflow: hidden;
		z-index: 0;
	}
	footer{
		margin: auto;
	}
	p{
		display: inline-block;
		color: #a3a5a8;
	}
</style>
</body>
</html>
<div style="clear: both"></div>
<div class="footer">
<footer>

	<div class="footer-inside">
	
	<p>&copy; 2017</p><p>Whatcom Community College</p>
	<h2 style="color: #a3a5a8; font-size: 24px">This publication was created with funds from a National Science Foundation grant, DUE-1500375. </h2>
	<a href="http://cwwinternship.cyberwatchwest.org/internship/adminsignin.php">SITE ADMINISTRATOR</a>
	</div>
</footer>
</div>


